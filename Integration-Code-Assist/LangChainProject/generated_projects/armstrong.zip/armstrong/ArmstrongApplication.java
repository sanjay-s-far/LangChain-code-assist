package com.example.armstrong;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArmstrongApplication {

    public static void main(String[] args) {
        SpringApplication.run(ArmstrongApplication.class, args);
    }
}