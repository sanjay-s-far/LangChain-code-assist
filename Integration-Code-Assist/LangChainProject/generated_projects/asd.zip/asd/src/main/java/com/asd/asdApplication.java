package com.asd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsdApplication {

    public static void main(String[] args) {
        SpringApplication.run(AsdApplication.class, args);
    }

}