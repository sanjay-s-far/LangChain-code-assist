package com.brd1.brd1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class brd1Application {

    public static void main(String[] args) {
        SpringApplication.run(brd1Application.class, args);
    }

}