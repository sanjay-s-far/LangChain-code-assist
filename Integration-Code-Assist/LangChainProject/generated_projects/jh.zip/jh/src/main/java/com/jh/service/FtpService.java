package com.jh.service;

import org.springframework.stereotype.Service;

@Service
public class FtpService {

    //TODO: Implement FTP operations (read/write XML)
}