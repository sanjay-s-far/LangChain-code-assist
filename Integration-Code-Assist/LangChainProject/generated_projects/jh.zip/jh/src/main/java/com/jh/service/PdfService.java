package com.jh.service;

import org.springframework.stereotype.Service;

@Service
public class PdfService {

    //TODO: Implement PDF generation logic
}