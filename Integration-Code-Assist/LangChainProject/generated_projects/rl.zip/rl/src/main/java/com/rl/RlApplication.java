package com.rl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RlApplication {

    public static void main(String[] args) {
        SpringApplication.run(RlApplication.class, args);
    }

}