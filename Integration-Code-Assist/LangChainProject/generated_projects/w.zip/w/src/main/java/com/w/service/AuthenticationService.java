package com.w.service;

import org.springframework.stereotype.Service;

@Service
public class AuthenticationService {
    // Authentication logic can be added here if needed beyond basic auth.
}